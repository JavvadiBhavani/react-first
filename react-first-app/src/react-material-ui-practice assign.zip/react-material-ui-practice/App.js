import MUiImgbg from "./components/MuiBgImg";
import MuiBlog from "./components/MuiBlog";
import MuiBut from "./components/MuiBut";
import MuiCont from "./components/Muicontent";
import Muifoot from "./components/MuiFooter";
import MuiPaper from "./components/MuiPaperdiv";
function App() {
  return (
    <div style={{marginLeft:'20px',marginRight:'20px'}}>
      
  <MuiBlog/><MuiBut/><MUiImgbg/><MuiPaper/><MuiCont/><Muifoot/>
    </div>
  );
}

export default App;